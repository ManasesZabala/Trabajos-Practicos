#include <stdio.h>
#include <stdlib.h>
typedef struct{
        char linea[20];
        int nucleos;
}eProcesador;

typedef struct{
    char marca[20];
    eProcesador procesador;
    int ram;
    float precio;
}eNotebook;

void inicializarNotebook(eNotebook*);

int main()
{
    eNotebook maquina1;

    inicializarNotebook(&maquina1);



    printf("Marca: %s Procesador: linea %s nucleos: %d RAM: %d Precio: %.2f\n", maquina1.marca, maquina1.procesador.linea, maquina1.procesador.nucleos, maquina1.ram, maquina1.precio);

    return 0;
}

void inicializarNotebook(eNotebook* x){

 printf("Ingrese marca: ");
    fflush(stdin);
    gets(x->marca);
    printf("Ingrese linea procesador: ");
    fflush(stdin);
    gets(x->procesador.linea);
    printf("Ingrese cantida de nucleos: ");
    fflush(stdin);
    scanf("%d", &x->procesador.nucleos);
    printf("Ingrese cantidad de ram: ");
    fflush(stdin);
    scanf("%d", &x->ram);
    printf("Ingrese precio: ");
    fflush(stdin);
    scanf("%f", &x->precio);

}
