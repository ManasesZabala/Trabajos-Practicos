#include <stdio.h>
#include <stdlib.h>

void swap(int* , int*);

int main()
{
   int x = 8;
   int y = 5;

     printf("Estoy en la funcion main antes del swap\n\n");
    printf("x = %d\n", x);
    printf("y = %d\n", y);


    swap(&x, &y);

    printf("Estoy en la funcion main despues del swap\n\n");
    printf("x = %d\n", x);
    printf("y = %d\n", y);

    return 0;
}

void swap(int* p, int* q){

int aux;
 aux = *p;
 *p = *q;
 *q = aux;

 printf("Estoy en la funcion swap\n\n");

  printf("x = %d\n", *p);
  printf("y = %d\n", *q);
}
