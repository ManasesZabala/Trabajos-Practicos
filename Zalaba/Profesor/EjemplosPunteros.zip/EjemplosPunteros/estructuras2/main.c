#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
        char linea[20];
        int nucleos;
}eProcesador;

typedef struct{
    char marca[20];
    eProcesador procesador;
    int ram;
    float precio;
}eNotebook;

void new_Notebook(eNotebook*);
void mostrarNotebook(eNotebook*);

int main()
{
    eNotebook maquina1;

    //new_Notebook(&maquina1);

    mostrarNotebook(&maquina1);

    return 0;
}

void new_Notebook(eNotebook* x){

    strcpy(x->marca, "");
    strcpy(x->procesador.linea, "");
    x->procesador.nucleos = 0;
    x->ram = 0;
    x->precio = 0;

}

void mostrarNotebook(eNotebook* x){

printf("Marca: %s Procesador: linea %s nucleos: %d RAM: %d Precio: %.2f\n", x->marca, x->procesador.linea, x->procesador.nucleos, x->ram, x->precio);


}
